package com.capgemini.mf2hadoop.domain;

public class FieldDataSingleObject implements FieldData {
	private DataDTO dto;

	public DataDTO getDto() {
		return dto;
	}

	public void setDto(DataDTO dto) {
		this.dto = dto;
	}
	
}
