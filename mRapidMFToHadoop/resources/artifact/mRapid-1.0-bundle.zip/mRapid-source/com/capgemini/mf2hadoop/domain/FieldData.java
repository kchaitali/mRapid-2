package com.capgemini.mf2hadoop.domain;

public interface FieldData {

}
